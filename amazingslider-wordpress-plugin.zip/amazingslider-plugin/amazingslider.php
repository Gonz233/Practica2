<?php
/*
Plugin Name: Amazing Slider
Plugin URI: http://amazingslider.com
Description: Amazing Slider WordPress Plugin
Version: 4.2
Author: Magic Hills Pty Ltd
Author URI: http://amazingslider.com
License: Copyright 2015 Magic Hills Pty Ltd, All Rights Reserved
*/

define('AMAZINGSLIDER_VERSION', '4.2');

define('AMAZINGSLIDER_URL', plugin_dir_url( __FILE__ ));

define('AMAZINGSLIDER_PATH', plugin_dir_path( __FILE__ ));

require_once 'app/class-amazingslider-controller.php';

class AmazingSlider_Plugin

{
	public $amazingslider_controller;
	
	function __construct() {
		
		$this->init();
	}
	
	public function init()
	{
		
		$this->amazingslider_controller = new AmazingSlider_Controller();

		register_activation_hook( __FILE__, array($this, 'activation_handler') );
		
		add_action( 'admin_menu', array($this, 'register_menu') );
		
		add_shortcode( 'amazingslider', array($this, 'shortcode_handler') );
		
		add_action( 'init', array($this, 'register_script') );
		add_action( 'wp_enqueue_scripts', array($this, 'enqueue_script') );
		add_action( 'admin_enqueue_scripts', array($this, 'enqueue_admin_script') );
	}
	
	function activation_handler()
	{
		$this->amazingslider_controller->activation_handler();
	}
	
	function enqueue_admin_script($hook)

	{
		if ($hook == 'admin_page_amazingslider_view_slider')

			wp_enqueue_script('amazingslider-script');

	}
	
	function enqueue_script()
	{
		wp_enqueue_script('amazingslider-script');
	}
	
	function register_script()
	{
		$uploads = wp_upload_dir();
		$script_url = $uploads['baseurl'] . '/amazingslider/sharedengine/amazingslider.js';
	
		wp_register_script('amazingslider-script', $script_url, array('jquery'), AMAZINGSLIDER_VERSION, false);
		
		if ( is_admin() )

		{

			wp_register_style('amazingslider-style', AMAZINGSLIDER_URL . 'amazingslider.css');

			wp_enqueue_style('amazingslider-style');

		}
	}
	
	function shortcode_handler($atts)
	{
		if ( !isset($atts['id']) )
			return __('Please specify a slider id', 'amazingslider');
		
		$id = $atts['id'];
		return $this->amazingslider_controller->generate_body_code($id);
	}
	
	function register_menu()
	{
		add_menu_page( 
				__('Amazing Slider', 'amazingslider'), 
				__('Amazing Slider', 'amazingslider'), 
				'manage_options', 
				'amazingslider_show_sliders', 
				array($this, 'show_sliders'),
				AMAZINGSLIDER_URL . 'images/logo-16.png' );
				
		add_submenu_page(
				'amazingslider_show_sliders', 
				__('Installed Sliders', 'amazingslider'), 
				__('Installed Sliders', 'amazingslider'), 
				'manage_options',
				'amazingslider_show_sliders',
				array($this, 'show_sliders' ) );
		
		add_submenu_page(

				'amazingslider_show_sliders',

				__('Add New slider', 'amazingslider'),

				__('Add New', 'amazingslider'),

				'manage_options',

				'amazingslider_add_new',

				array($this, 'add_new' ) );
		
		add_submenu_page(

				null,

				__('View Slider', 'amazingslider'),

				__('View Slider', 'amazingslider'),

				'manage_options',

				'amazingslider_view_slider',

				array($this, 'view_slider' ) );
	}
	
	public function show_sliders()
	{
		$this->amazingslider_controller->show_sliders();
	}
	
	public function add_new()
	{
		$this->amazingslider_controller->add_new();
	}
	
	public function view_slider()
	{
		$this->amazingslider_controller->view_slider();
	}
}

$amazingslider_plugin = new AmazingSlider_Plugin();

/**
 * Global php function
 * @param unknown_type $id
 */
function amazingslider($id) {
	
	echo $amazingslider_plugin->amazingslider_controller->generate_body_code($id);
}

/**
 * Uninstallation
 */
function amazingslider_uninstall() {


	global $wpdb;
	

	$table_name = $wpdb->prefix . "amazingslider";

	$wpdb->query("DROP TABLE IF EXISTS $table_name");

}

if ( function_exists('register_uninstall_hook') )
	register_uninstall_hook( __FILE__, 'amazingslider_uninstall' );

