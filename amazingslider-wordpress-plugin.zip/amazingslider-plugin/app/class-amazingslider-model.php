<?php 

require_once 'functions.php';

class AmazingSlider_Model {

	private $controller;
	
	function __construct($controller) {
		
		$this->controller = $controller;
		
	}
	
	function get_upload_path() {
		
		$uploads = wp_upload_dir();
		
		return $uploads['basedir'] . '/amazingslider/';
	}
	
	function get_upload_url() {
	
		$uploads = wp_upload_dir();
	
		return $uploads['baseurl'] . '/amazingslider/';
	}
	
	function install_slider_from_folder($install_folder, $id) {
				
		// write to db
		$ret = $this->add_slider_to_db($install_folder . 'data/', $id);
		if ( is_wp_error($ret) )
			return $ret;
		
		// copy to uploads folder
		$upload_folder = $this->get_upload_path();
		if ( !is_dir( $upload_folder ) )
		{
			if ( 0 == wp_mkdir_p( $upload_folder ) )
				return new WP_Error('filesystem', __("Cannot create folder", "amazingslider"));
		}
		
		$slider_folder = $upload_folder . $ret['id'] . '/';
		if ( is_dir( $slider_folder ) )
			amazingslider_recurse_rmdir( $slider_folder );
		if ( 0 == wp_mkdir_p( $slider_folder ) )
			return new WP_Error('filesystem', __("Cannot create folder", "amazingslider"));
		
		amazingslider_recurse_copy($install_folder . 'data/', $slider_folder);
		
		// copy sharedengine to upload folder
		$sharedengine_folder = $upload_folder . 'sharedengine/';
		if ( is_dir( $sharedengine_folder ) )
			amazingslider_recurse_rmdir( $sharedengine_folder );
		if ( 0 == wp_mkdir_p( $sharedengine_folder ) )
			return new WP_Error('filesystem', __("Cannot create folder", "amazingslider"));
		
		amazingslider_recurse_copy($install_folder . 'sharedengine/', $sharedengine_folder);
		
		// modify id of slider
		$file = $slider_folder . 'sliderengine/initslider.js';
		$content = file_get_contents($file);
		$content = str_replace("%SLIDERID%", $ret['id'], $content);
		$jsfolder = $this->get_upload_url() . $ret['id'] . '/sliderengine/';
		$content = str_replace("%JSFOLDER%", $jsfolder, $content);
		file_put_contents($file, $content);
		
		// modify id of slider css
		$file = $slider_folder . 'sliderengine/amazingslider.css';
		$content = file_get_contents($file);
		$content = str_replace("%SLIDERID%", $ret['id'], $content);
		$jsfolder = $this->get_upload_url() . $ret['id'] . '/sliderengine/';
		$content = str_replace("%JSFOLDER%", $jsfolder, $content);
		file_put_contents($file, $content);
						
		return array(
				"id" => $ret['id']);
	}
	
	function install_slider($zipfile, $id) {
				
		// unzip
		$unzip_folder = trailingslashit ( dirname( $zipfile ) );
		
		$ret = amazingslider_unzip_file($zipfile, $unzip_folder);
		if ( is_wp_error($ret) )
			return $ret;
		
		unlink( $zipfile );
		
		$ret = $this->install_slider_from_folder( $unzip_folder . "amazingslider-plugin/", $id );
		if ( is_wp_error($ret) )
			return $ret;
		
		// check new version
		$ret["new"] = false;
		
		$file = $unzip_folder . "amazingslider-plugin/" . "amazingslider.php";
		$content = file_get_contents($file);
		$pattern = '/define\(\'AMAZINGSLIDER_VERSION\', \'([0-9\.]+)\'\);/';
		if ( preg_match($pattern, $content, $matches) )
		{
			if ( floatval($matches[1]) > floatval(AMAZINGSLIDER_VERSION) )
				$ret["new"] = true;
		}
		
		amazingslider_recurse_rmdir( $unzip_folder . "amazingslider-plugin/" );
		
		return $ret;
	}
	
	
	function add_slider_to_db($folder, $id) {
		
		$this->create_db_table();
		return $this->insert_slider_to_db_table($folder, $id);
	}
	
	function is_db_table_exists() {
		
		global $wpdb;
		$table_name = $wpdb->prefix . "amazingslider";
		
		return ( $wpdb->get_var("SHOW TABLES LIKE '$table_name'") == $table_name );
	}
	
	function create_db_table() {
		
		global $wpdb;
		$table_name = $wpdb->prefix . "amazingslider";
		
		$charset = '';
		if ( !empty($wpdb -> charset) ) 
			$charset = "DEFAULT CHARACTER SET $wpdb->charset";
		if ( !empty($wpdb -> collate) ) 
			$charset .= " COLLATE $wpdb->collate";
		
		$sql = "CREATE TABLE $table_name (
		id mediumint(9) NOT NULL AUTO_INCREMENT,
		time datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
		authorid tinytext NOT NULL,
		name tinytext DEFAULT '' NOT NULL,
		images text DEFAULT '' NOT NULL,
		slidercode text DEFAULT '' NOT NULL,
		PRIMARY KEY  (id)
		) $charset;";
			
		require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
		dbDelta($sql);
	}
	
	function insert_slider_to_db_table($folder, $id) {
		
		global $wpdb, $user_ID;
		$table_name = $wpdb->prefix . "amazingslider";
		
		$file = $folder . "slider.html";
		if ( !is_file($file) )
			return new WP_Error('filesystem', __("Cannot find slider file", "amazingslider"));
		
		$time = current_time('mysql');
		$authorid = $user_ID;
		
		if ( ($id > 0) && $this->is_id_exist($id) )
		{
			$ret = $wpdb->query( $wpdb->prepare(
					"
					UPDATE $table_name
					SET time=%s, authorid=%s 
					WHERE id=%d
					",
					$time,
					$authorid,
					$id
			) );	
			if (!$ret)
				return new WP_Error('wp_db', __("Cannot insert slider to database", "amazingslider"));
		}
		else
		{
			$ret = $wpdb->query( $wpdb->prepare(
					"
					INSERT INTO $table_name (time, authorid, name, images, slidercode)
					VALUES (%s, %s, %s, %s, %s)
					",
					$time,
					$authorid,
					"",
					"",
					""
			) );
			if (!$ret)
				return new WP_Error('wp_db', __("Cannot insert slider to database", "amazingslider"));
			
			$id = $wpdb->insert_id;
		}
		
		$ret = $this->read_slider($file, $id);
		if ( is_wp_error($ret) )
			return $ret;
		
		$name = $ret['name'];
		$images = $ret['images'];
		$slidercode = $ret['slidercode'];
		
		$ret = $wpdb->query( $wpdb->prepare(
				"
				UPDATE $table_name 
				SET name=%s, images=%s, slidercode=%s 
				WHERE id=%d
				",
				$name,
				$images,
				$slidercode,
				$id
		) );
		
		return array(
				"id" => $id);
	}
	
	function read_slider($file, $id) {
		
		$dest_url = $this->get_upload_url() . $id . '/';
		$content = file_get_contents($file);
		
		$name = "";
		$pattern = '/<title>(.*)<\/title>/';
		if ( preg_match($pattern, $content, $matches) )
			$name = $matches[1];
						
		$slidercode = "";
		$pattern = '/<!-- Insert to your webpage where you want to display the slider -->(.*)<!-- End of body section HTML codes -->/s';
		if ( preg_match($pattern, $content, $matches) )
		{
			$slidercode = str_replace("%DESTURL%", $dest_url, $matches[1]);
			$slidercode = str_replace("%SLIDERID%", $id, $slidercode);
		}
		
		$imagescode = $slidercode;
		$pattern = '/<ul class=[\"\']amazingslider-slides[\"\'].*<\/ul>/sU';
		if ( preg_match($pattern, $slidercode, $matches) )
		{
			$imagescode = $matches[0];
		}
		
		$images = "";
		$pattern = '/<img (data-)*src="([^"]+)"/';
		if ( preg_match_all($pattern, $imagescode, $matches) )
			$images = serialize($matches[2]);
	
		return array(
				"name" => $name,
				"images" => $images,
				"slidercode" => $slidercode);
	}
	
	function is_id_exist($id)
	{
		global $wpdb;
		$table_name = $wpdb->prefix . "amazingslider";
		
		$slider_row = $wpdb->get_row( $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id) );
		return ($slider_row != null);
	}
	
	function generate_body_code($id)
	{
		global $wpdb;
		$table_name = $wpdb->prefix . "amazingslider";
		
		$ret = "";
		$slider_row = $wpdb->get_row( $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $id) );
		if ($slider_row != null)
		{
			$ret = $slider_row->slidercode;
			$css_file = $this->get_upload_path() . $id . '/sliderengine/amazingslider.css';
			if (file_exists($css_file))
				$ret .= '<link rel="stylesheet" type="text/css" href="' . $this->get_upload_url() . $id . '/sliderengine/amazingslider.css">' . "\n";
			$ret .= '<script src="' . $this->get_upload_url() . $id . '/sliderengine/initslider.js"></script>' . "\n";
		}
		else 
		{
			$ret = '<p>The specified slider id does not exist.</p>';
		}
		return $ret;
	}
	
	function get_list_data()
	{
		
		global $wpdb;
		$table_name = $wpdb->prefix . "amazingslider";
		
		$slider_rows = $wpdb->get_results( "SELECT * FROM $table_name", ARRAY_A);
		
		$ret = array();
		
		if ( $slider_rows )
		{
			foreach ( $slider_rows as $row )
			{
				$ret[] = array(
							"id" => $row['id'],
							'name' => $row['name'],
							'images' => $row['images'],
							'time' => $row['time'],
							'author' => $row['authorid']
						);
			}
		}
		
		return $ret;
	}
	
	function delete_slider($id)
	{
		global $wpdb;
		$table_name = $wpdb->prefix . "amazingslider";
		
		$ret = $wpdb->query( $wpdb->prepare(
				"
				DELETE FROM $table_name WHERE id=%s
				",
				$id
		) );
		
		return $ret;
	}
}