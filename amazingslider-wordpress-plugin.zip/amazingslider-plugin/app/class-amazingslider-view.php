<?php 

require_once 'class-amazingslider-list-table.php';

class AmazingSlider_View {

	private $controller;
	private $list_table;
	
	function __construct($controller) {
		
		$this->controller = $controller;
	}
	
	function print_add_new() {
		
		if ( !empty($_POST) && (isset($_POST['amzingslider-upload']) || isset($_POST['amzingslider-upload-url']) || isset($_POST['amzingslider-upload-folder'])) && wp_verify_nonce($_POST['amazingslider-nonce'],'amazingslider-add-new-add-new') )
		{	
			if ( isset($_POST['amzingslider-upload']) )	
			{	
				if ( !isset($_FILES['amazingslider-zip']) || ($_FILES["amazingslider-zip"]["error"] > 0) )
				{
					if ($_FILES["amazingslider-zip"]["error"] == 1)
						echo '<div class="error"><p>' . __('The uploaded file exceeds the upload_max_filesize directive in php.ini', 'amazingslider')  . '</p></div>';
					else
						echo '<div class="error"><p>' . __('Please select a ZIP file created with Amazing Slider', 'amazingslider')  . '</p></div>';
				}
				else
				{		
					$uploadfile = wp_handle_upload($_FILES['amazingslider-zip'], array(
							'test_form' => false,
							'mimes' => array('zip' => 'application/zip')
					));
					
					if ( isset($uploadfile['error']) )
					{
						echo '<div class="error"><p>' . esc_attr($uploadfile['error'])  . '</p></div>';
					}
					else
					{
						$id = ( isset($_POST['amazingslider-replace']) && ($_POST['amazingslider-replace'] == 'yes') && isset($_POST['amazingslider-replace-id']) ) ? ($_POST['amazingslider-replace-id']) : -1;
						$ret = $this->controller->install_slider($uploadfile['file'], $id);
						if ( is_wp_error($ret) )
						{
							echo '<div class="error"><p>' . $ret->get_error_message()  . '</p></div>';
						}
						else
						{		
							if ( $ret["new"] )
								echo '<div class="error"><p>This is a new version Amazing Slider WordPress Plugin. In addition to adding the Slider here, you also need to update the Plugin itself. Fore more inforamtion, visit <a href="http://amazingslider.com/how-to-update-amazing-slider-wordpress-plugin/" target="_blank">How to update Amazing Slider WordPress Plugin</a>.</p></div>';
															
							echo '<div class="updated"><p>The slider is successfully installed. &nbsp;&nbsp;<a href="?page=amazingslider_view_slider&sliderid=' . $ret["id"] . '">View The Slider</a></p></div>';
							echo '<div class="updated"><p> To embed the slider into your page, use shortcode <strong>[amazingslider id="' . $ret["id"] . '"]</strong></p></div>';
							echo '<div class="updated"><p> To embed the slider into your template, use php code <strong>' . esc_attr('<?php echo do_shortcode(\'[amazingslider id="' . $ret["id"] . '"]\'); ?>') . '</strong></p></div>';						
						}
					}
				}
			}
			else if ( isset($_POST['amzingslider-upload-url']) )
			{				
				if ( !isset($_POST['amazingslider-zip-url']) || strlen($_POST['amazingslider-zip-url']) == 0)	
				{
					echo '<div class="error"><p>' . __('Please specify a URL of ZIP file created with Amazing Slider', 'amazingslider')  . '</p></div>';
				}	
				else
				{
					$accepted_status_codes = array( 200, 301, 302 );
					$response = wp_remote_head( $_POST['amazingslider-zip-url'] );
					if ( is_wp_error( $response ) || !in_array( wp_remote_retrieve_response_code( $response ), $accepted_status_codes ) ) {
						echo '<div class="error"><p>' . __('The specified URL does not exist', 'amazingslider')  . '</p></div>';
					}
					else
					{				
						$uploadfile = fopen($_POST['amazingslider-zip-url'], "r");
						if ( !$uploadfile )
						{
							echo '<div class="error"><p>' . __('The specified URL does not exist', 'amazingslider')  . '</p></div>';
						}
						else
						{						
							$uploads = wp_upload_dir();
							$zipfile = $uploads['basedir'] . '/amazingslider/amazingslider-url-upload.zip';
							
							while ( !feof($uploadfile) )
							{
								file_put_contents($zipfile, fread($uploadfile, 4096), FILE_APPEND);
							}
							fclose($uploadfile);
							
							$id = ( isset($_POST['amazingslider-replace']) && ($_POST['amazingslider-replace'] == 'yes') && isset($_POST['amazingslider-replace-id']) ) ? ($_POST['amazingslider-replace-id']) : -1;
							$ret = $this->controller->install_slider($zipfile, $id);
							if ( is_wp_error($ret) )
							{
								echo '<div class="error"><p>' . $ret->get_error_message()  . '</p></div>';
							}
							else
							{
								if ( $ret["new"] )
									echo '<div class="error"><p>This is a new version Amazing Slider WordPress Plugin. In addition to adding the slider here, you also need to update the Plugin itself. Fore more inforamtion, visit <a href="http://amazingslider.com/how-to-update-amazing-slider-wordpress-plugin/" target="_blank">How to update Amazing Slider WordPress Plugin</a>.</p></div>';
									
								echo '<div class="updated"><p>The slider is successfully installed. &nbsp;&nbsp;<a href="?page=amazingslider_view_slider&sliderid=' . $ret["id"] . '">View The Slider</a></p></div>';
								echo '<div class="updated"><p> To embed the slider into your page, use shortcode <strong>[amazingslider id="' . $ret["id"] . '"]</strong></p></div>';
								echo '<div class="updated"><p> To embed the slider into your template, use php code <strong>' . esc_attr('<?php echo do_shortcode(\'[amazingslider id="' . $ret["id"] . '"]\'); ?>') . '</strong></p></div>';
							}
						}
					}
				}
			}
			else if ( isset($_POST['amzingslider-upload-folder']) )
			{				
				if ( !isset($_POST['amazingslider-zip-folder']) || strlen(trim($_POST['amazingslider-zip-folder'])) == 0)
				{
					echo '<div class="error"><p>' . __('Please specify a folder for the unzipped plugin files', 'amazingslider')  . '</p></div>';
				}
				else
				{
					$install_folder = trim($_POST['amazingslider-zip-folder']);
					$id = ( isset($_POST['amazingslider-replace']) && ($_POST['amazingslider-replace'] == 'yes') && isset($_POST['amazingslider-replace-id']) ) ? ($_POST['amazingslider-replace-id']) : -1;
					$ret = $this->controller->install_slider_from_folder($install_folder, $id);
					if ( is_wp_error($ret) )
					{
						echo '<div class="error"><p>' . $ret->get_error_message()  . '</p></div>';
					}
					else
					{
						if ( $ret["new"] )
							echo '<div class="error"><p>This is a new version Amazing Slider WordPress Plugin. In addition to adding the slider here, you also need to update the Plugin itself. Fore more inforamtion, visit <a href="http://amazingslider.com/how-to-update-amazing-slider-wordpress-plugin/" target="_blank">How to update Amazing Slider WordPress Plugin</a>.</p></div>';
							
						echo '<div class="updated"><p>The slider is successfully installed. &nbsp;&nbsp;<a href="?page=amazingslider_view_slider&sliderid=' . $ret["id"] . '">View The Slider</a></p></div>';
						echo '<div class="updated"><p> To embed the slider into your page, use shortcode <strong>[amazingslider id="' . $ret["id"] . '"]</strong></p></div>';
						echo '<div class="updated"><p> To embed the slider into your template, use php code <strong>' . esc_attr('<?php echo do_shortcode(\'[amazingslider id="' . $ret["id"] . '"]\'); ?>') . '</strong></p></div>';
					}
				}
			}
		}
		?>
		<div class="wrap">
			<div id="icon-amazingslider" class="icon32"><br /></div>
			
			<h2><?php _e( 'Add New Slider', 'amazingslider' ); ?> <a href="<?php echo admin_url('admin.php?page=amazingslider_show_sliders'); ?>" class="add-new-h2">Show All Sliders</a></h2>
									
			<form id="form-amazingslider-add-new" method="post" enctype="multipart/form-data"> 
				<ul>
					<li>
						<h3><?php _e( 'Upload the ZIP file created with <a href="http://amazingslider.com" target="_blank">Amazing Slider</a>:', 'amazingslider' ); ?></h3>
						<input type="file" id="amazingslider-zip" name="amazingslider-zip" />
						<input id="amzingslider-upload" name="amzingslider-upload" type="submit" class="button" value="<?php esc_attr_e('Install', 'amazingslider') ?>" />
					</li> 
					<li>
						<h3><?php _e( 'Or install the ZIP file from URL:', 'amazingslider' ); ?></h3>
						<p><?php _e( 'If the ZIP file is too large, you can upload the file to your web server via FTP, then install the ZIP file from URL.', 'amazingslider' ); ?></p>
						<input type="text" id="amazingslider-zip-url" name="amazingslider-zip-url" size="60" />
						<input id="amzingslider-upload-url" name="amzingslider-upload-url" type="submit" class="button" value="<?php esc_attr_e('Install', 'amazingslider') ?>" />
						<p><strong><?php _e( '* Installing may take a while depending on the size of your ZIP file. Please be patient.', 'amazingslider' ); ?></strong></p>
					</li> 
					<li>
						<h3><?php _e( 'Or install the plugin from folder:', 'amazingslider' ); ?></h3>
						<p><?php _e( 'You can unzip the plugin ZIP file at local hard disk, then upload the plugin folder to your WordPress uploads folder, and install from the folder.', 'amazingslider' ); ?></p>
						
						<?php 
						$uploads = wp_upload_dir();
						$upload_folder = $uploads['basedir'] . "/amazingslider-plugin/";
						?>
						<input type="text" id="amazingslider-zip-folder" name="amazingslider-zip-folder" size="60" value="<?php echo $upload_folder; ?>" />
						<input id="amzingslider-upload-folder" name="amzingslider-upload-folder" type="submit" class="button" value="<?php esc_attr_e('Install', 'amazingslider') ?>" />
						<p><strong><?php _e( '* You can use this option if the above two options do not work on your WordPress website.', 'amazingslider' ); ?></strong></p>
					</li>
					<li>
						<input type="checkbox" name="amazingslider-replace" value="yes"><?php esc_attr_e('Replace an existing slider', 'amazingslider') ?>:&nbsp;
						<select name="amazingslider-replace-id">
							<?php 
							global $wpdb;
							$table_name = $wpdb->prefix . "amazingslider";
							$slider_rows = $wpdb->get_results( "SELECT * FROM $table_name", ARRAY_A);						
							if ( $slider_rows )
							{
								foreach ( $slider_rows as $row )
									echo '<option value="' . $row['id'] . '">' . $row['id'] . ' : ' . $row['name'] . '</option>';
							}
							?>
						</select>
					</li>
	  			</ul>
	  			<?php wp_nonce_field('amazingslider-add-new-add-new','amazingslider-nonce'); ?>
	  		</form>              
		</div>
		<?php
	}
	
	function print_sliders() {
		
		?>
		<div class="wrap">
		<div id="icon-amazingslider" class="icon32"><br /></div>
			
		<h2><?php _e( 'Installed Sliders', 'amazingslider' ); ?> <a href="<?php echo admin_url('admin.php?page=amazingslider_add_new'); ?>" class="add-new-h2">Add New</a> </h2>
		
		<?php $this->process_delete_action(); ?>
		
		<form id="slider-list-table" method="post">
		<input type="hidden" name="page" value="<?php echo $_REQUEST['page'] ?>" />
		<?php 
		
		if ( !is_object($this->list_table) )
			$this->list_table = new AmazingSlider_List_Table($this);
		$this->list_table->list_data = $this->controller->get_list_data();
		$this->list_table->prepare_items();
		$this->list_table->display();		
		?>								
        </form>
        
		</div>
		<?php
	}
	
	function process_delete_action()
	{
		$deleted = 0;
		
		if ( isset($_REQUEST['action']) && ($_REQUEST['action'] == 'delete') && isset( $_REQUEST['sliderid'] ) )
		{
			if ( is_array( $_REQUEST['sliderid'] ) )
			{
				foreach( $_REQUEST['sliderid'] as $id)
				{
					$ret = $this->controller->delete_slider($id);
					if ($ret > 0)
						$deleted += $ret;
				}
			}
			else
			{
				$deleted = $this->controller->delete_slider( $_REQUEST['sliderid'] );
			}
		}
	
		if ($deleted > 0)
		{
			echo '<div class="updated"><p>';
			printf( _n('%d slider deleted.', '%d sliders deleted.', $deleted), $deleted );
			echo '</p></div>';
		}
		
	}
	
	function view_slider()
	{
		if ( !isset( $_REQUEST['sliderid'] ) )
			return;
		
		?>
		<div class="wrap">
		<div id="icon-amazingslider" class="icon32"><br /></div>
					
		<h2><?php _e( 'View Slider', 'amazingslider' ); ?> <a href="<?php echo admin_url('admin.php?page=amazingslider_show_sliders'); ?>" class="add-new-h2">Show All Sliders</a> <a href="<?php echo admin_url('admin.php?page=amazingslider_add_new'); ?>" class="add-new-h2">Add New</a> </h2>
		
		<div class="updated"><p style="text-align:center;"> To embed the slider into your page, use shortcode <strong><?php echo esc_attr('[amazingslider id="' . $_REQUEST['sliderid'] . '"]'); ?></strong></p></div>

		<div class="updated"><p style="text-align:center;"> To embed the slider into your template, use php code <strong><?php echo esc_attr('<?php echo do_shortcode(\'[amazingslider id="' . $_REQUEST['sliderid'] . '"]\'); ?>'); ?></strong></p></div>
		
		<?php
		echo $this->controller->generate_body_code( $_REQUEST['sliderid'] ); 
		?>	 

		</div>
		<?php
	}
		
}