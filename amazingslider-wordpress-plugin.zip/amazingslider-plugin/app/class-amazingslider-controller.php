<?php 

require_once 'class-amazingslider-model.php';
require_once 'class-amazingslider-view.php';

class AmazingSlider_Controller {

	private $view, $model;

	function __construct() {

		$this->model = new AmazingSlider_Model($this);	
		$this->view = new AmazingSlider_View($this);
	}

	function add_new() {
		
		$this->view->print_add_new();
	}
	
	function show_sliders() {
		
		$this->view->print_sliders();
	}
	
	function view_slider()
	{
		$this->view->view_slider();
	}
	
	function install_slider($zipfile, $id) {
		
		return $this->model->install_slider($zipfile, $id);
	}
	
	function install_slider_from_folder($install_folder, $id) {
		
		return $this->model->install_slider_from_folder($install_folder, $id);
	}
	
	function generate_body_code($id) {
		
		return $this->model->generate_body_code($id);
	}
	
	function get_list_data() {
		
		return $this->model->get_list_data();
	}
	
	function delete_slider($id)
	{
		return $this->model->delete_slider($id);
	}
	
	function activation_handler()
	{
		if ( !$this->model->is_db_table_exists() )
			$this->model->install_slider_from_folder( AMAZINGSLIDER_PATH, -1);
	}
}